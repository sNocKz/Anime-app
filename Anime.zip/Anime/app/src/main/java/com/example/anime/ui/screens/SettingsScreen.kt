package com.example.anime.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import kotlin.random.Random

data class GameState(
    val impostors: List<String> = emptyList(),
    val word: String = "",
    val currentPlayerIndex: Int = -1,
    val revealedPlayers: Set<String> = emptySet(),
    val gameStarted: Boolean = false,
    val roleRevealed: Boolean = false,
    val allPlayersRevealed: Boolean = false,
    val selectedStartingPlayer: String = ""
)

@Composable
fun SettingsScreen(
    onNavigateBack: () -> Unit
) {
    var showPlayerNameDialog by remember { mutableStateOf(false) }
    var playerNames by remember { mutableStateOf(List(3) { "Player ${it + 1}" }) }
    var selectedCategories by remember { 
        mutableStateOf(setOf<String>()) 
    }
    var impostorCount by remember { mutableStateOf(1) }
    var useRandomImpostors by remember { mutableStateOf(false) }
    var gameState by remember { mutableStateOf(GameState()) }
    
    // Track expanded state for each section
    var spielerExpanded by remember { mutableStateOf(false) }
    var impostorExpanded by remember { mutableStateOf(false) }
    var kategorienExpanded by remember { mutableStateOf(false) }
    
    // Track expanded state for each category
    val categories = listOf("Anime", "Character", "Abilities/Items")
    var expandedCategory by remember { mutableStateOf<String?>(null) }

    // Words for each category
    val categoryWords = mapOf(
        "Anime" to listOf(
            "Naruto",
            "One Piece",
            "Dragon Ball",
            "Pokémon",
            "My Hero Academia",
            "Demon Slayer",
            "Attack on Titan",
            "Sword Art Online",
            "Death Note",
            "Fairy Tail",
            "Tokyo Revengers",
            "One Punch Man",
            "Bleach",
            "Black Clover",
            "Haikyuu!!",
            "Spy x Family",
            "The Seven Deadly Sins",
            "Jujutsu Kaisen",
            "Fullmetal Alchemist: Brotherhood",
            "Boruto: Naruto Next Generations",
            "Inuyasha",
            "Digimon",
            "Yu-Gi-Oh!",
            "Noragami",
            "Kakegurui",
            "Assassination Classroom",
            "Dr. Stone",
            "Re:Zero",
            "Hunter x Hunter",
            "Chainsaw Man",
            "Fire Force",
            "Erased",
            "The Promised Neverland",
            "Akame ga Kill",
            "No Game No Life"
        ),
        "Character" to listOf(
            "Naruto Uzumaki (Naruto)",
            "Son Goku (Dragon Ball)",
            "Monkey D. Luffy (One Piece)",
            "Ash Ketchum (Pokémon)",
            "Izuku Midoriya (My Hero Academia)",
            "Tanjiro Kamado (Demon Slayer)",
            "Eren Yeager (Attack on Titan)",
            "Kirito (Sword Art Online)",
            "Light Yagami (Death Note)",
            "Natsu Dragneel (Fairy Tail)",
            "Takemichi Hanagaki (Tokyo Revengers)",
            "Saitama (One Punch Man)",
            "Ichigo Kurosaki (Bleach)",
            "Asta (Black Clover)",
            "Shoyo Hinata (Haikyuu!!)",
            "Loid Forger (Spy x Family)",
            "Meliodas (The Seven Deadly Sins)",
            "Yuji Itadori (Jujutsu Kaisen)",
            "Edward Elric (Fullmetal Alchemist: Brotherhood)",
            "Boruto Uzumaki (Boruto: Naruto Next Generations)",
            "Inuyasha (Inuyasha)",
            "Yugi Mutou (Yu-Gi-Oh!)",
            "Yato (Noragami)",
            "Koro-sensei (Assassination Classroom)",
            "Senku Ishigami (Dr. Stone)",
            "Subaru Natsuki (Re:Zero)",
            "Gon Freecss (Hunter x Hunter)",
            "Satoru Fujinuma (Erased)",
            "Emma (The Promised Neverland)",
            "Akame (Akame ga Kill)",
            "Sora (No Game No Life)",
            "Sakura Haruno (Naruto)"
        ),
        "Abilities/Items" to listOf(
            "Kunai (Naruto)",
            "Dragon Radar (Dragon Ball)",
            "Strohhut (One Piece)",
            "Pokéball (Pokémon)",
            "Kellerschlüssel (Attack on Titan)",
            "Death Note (Death Note)",
            "Toman-Jacke (Tokyo Revengers)",
            "Helden-Umhang (One Punch Man)",
            "Zangetsu (Bleach)",
            "Grimoire (Black Clover)",
            "Volleyball (Haikyuu!!)",
            "Dämonenschwert (The Seven Deadly Sins)",
            "Verfluchter Finger (Jujutsu Kaisen)",
            "Ninja-Stirnband (Naruto)",
            "Fallenkarte (Yu-Gi-Oh!)",
            "Anti-Materie-Messer (Assassination Classroom)",
            "Angelrute (Hunter x Hunter)",
            "Schachbrett (No Game No Life)",
            "Apfel (Death Note)",
            "Sharingan (Naruto)",
            "Rasengan (Naruto)",
            "Kamehameha (Dragon Ball)",
            "Gomu Gomu no Mi (Gummifrucht) (One Piece)",
            "Pikachu's Donnerblitz (Pokémon)",
            "One For All (My Hero Academia)",
            "Titanenverwandlung (Attack on Titan)",
            "Shinigami-Augen (Death Note)",
            "Bankai (Bleach)",
            "Domain Expansion (Jujutsu Kaisen)",
            "Chakra (Naruto)",
            "Exodia (Yu-Gi-Oh!)",
            "Nen (Hunter x Hunter)",
            "Genjutsu (Naruto)",
            "Zeitreise (Erased)"
        )
    )

    // Function to adjust impostor count based on player count
    fun adjustImpostorCount(playerCount: Int) {
        when {
            playerCount < 7 && impostorCount > 2 -> impostorCount = 2  // Only reduce to 2 if below 7 players
            playerCount < 5 && impostorCount > 1 -> impostorCount = 1  // Only reduce to 1 if below 5 players
        }
    }

    // Function to get random number of impostors based on player count
    fun getRandomImpostorCount(playerCount: Int): Int {
        return when (playerCount) {
            5, 6 -> Random.nextInt(1, 3) // 1 or 2 impostors
            7, 8 -> Random.nextInt(1, 4) // 1, 2, or 3 impostors
            else -> 1 // Default to 1 impostor
        }
    }

    // Function to start the game
    fun startGame() {
        val finalImpostorCount = if (useRandomImpostors) {
            getRandomImpostorCount(playerNames.size)
        } else {
            impostorCount
        }

        // Randomly select impostors
        val shuffledPlayers = playerNames.shuffled()
        val selectedImpostors = shuffledPlayers.take(finalImpostorCount)

        // Select a random word from the selected categories
        val availableWords = selectedCategories.flatMap { category ->
            categoryWords[category] ?: emptyList()
        }
        val selectedWord = if (availableWords.isNotEmpty()) {
            availableWords.random()
        } else {
            "No word selected"
        }

        gameState = GameState(
            impostors = selectedImpostors,
            word = selectedWord,
            currentPlayerIndex = 0,
            gameStarted = true
        )
    }

    // Function to show next player
    fun showNextPlayer() {
        if (gameState.currentPlayerIndex < playerNames.size - 2) {
            gameState = gameState.copy(
                currentPlayerIndex = gameState.currentPlayerIndex + 1,
                roleRevealed = false
            )
        } else if (gameState.currentPlayerIndex == playerNames.size - 2) {
            // Last player
            gameState = gameState.copy(
                currentPlayerIndex = gameState.currentPlayerIndex + 1,
                roleRevealed = false
            )
        } else {
            // All players have been shown
            gameState = gameState.copy(
                allPlayersRevealed = true,
                selectedStartingPlayer = playerNames.random(),
                roleRevealed = false  // Reset roleRevealed for the final screen
            )
        }
    }

    // Function to reset the game
    fun resetGame() {
        gameState = GameState()
        // Don't reset useRandomImpostors setting
        if (!useRandomImpostors) {
            impostorCount = 1
        }
    }

    if (!gameState.gameStarted) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFF8B0000))
                .padding(16.dp)
        ) {
            Text(
                text = "Impostor",
                fontSize = 40.sp,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 32.dp)
            )

            // Spieler Section
            SettingsSection(
                title = "Spieler",
                expanded = spielerExpanded,
                onExpandClick = { spielerExpanded = !spielerExpanded }
            ) {
                if (spielerExpanded) {
                    Column(
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        playerNames.forEachIndexed { index, name ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = name,
                                    color = Color.White,
                                    modifier = Modifier.weight(1f)
                                )
                                if (playerNames.size > 3) {
                                    IconButton(
                                        onClick = {
                                            val newPlayerCount = playerNames.size - 1
                                            playerNames = playerNames.toMutableList().apply {
                                                removeAt(index)
                                            }
                                            adjustImpostorCount(newPlayerCount)
                                        }
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Delete,
                                            contentDescription = "Remove player",
                                            tint = Color.White
                                        )
                                    }
                                }
                            }
                        }
                        
                        if (playerNames.size < 8) {
                            Button(
                                onClick = { 
                                    if (playerNames.size < 8) {
                                        playerNames = playerNames + "Player ${playerNames.size + 1}"
                                    }
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Add,
                                    contentDescription = "Add player",
                                    modifier = Modifier.padding(end = 8.dp)
                                )
                                Text("Add Player")
                            }
                        }
                        
                        Button(
                            onClick = { showPlayerNameDialog = true },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 8.dp)
                        ) {
                            Text("Edit Player Names")
                        }
                    }
                }
            }

            // Impostor Section
            SettingsSection(
                title = "Impostor",
                expanded = impostorExpanded,
                onExpandClick = { impostorExpanded = !impostorExpanded }
            ) {
                if (impostorExpanded) {
                    Column(
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        // Random Impostor Checkbox
                        if (playerNames.size >= 5) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(bottom = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = useRandomImpostors,
                                    onCheckedChange = { useRandomImpostors = it },
                                    colors = CheckboxDefaults.colors(
                                        checkedColor = MaterialTheme.colorScheme.primary,
                                        uncheckedColor = Color.White
                                    )
                                )
                                Text(
                                    text = "Random Impostors",
                                    color = Color.White,
                                    modifier = Modifier.padding(start = 8.dp)
                                )
                            }
                        }

                        // Only show impostor count controls if not using random
                        if (!useRandomImpostors) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = "Impostor Count: $impostorCount",
                                    color = Color.White
                                )
                                Row {
                                    IconButton(
                                        onClick = { 
                                            if (impostorCount > 1) impostorCount--
                                        }
                                    ) {
                                        Text("-", color = Color.White)
                                    }
                                    IconButton(
                                        onClick = { 
                                            if ((playerNames.size >= 5 && impostorCount < 2) || 
                                                (playerNames.size >= 7 && impostorCount < 3)) {
                                                impostorCount++
                                            }
                                        }
                                    ) {
                                        Text("+", color = Color.White)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Categories Section
            SettingsSection(
                title = "Kategorien",
                expanded = kategorienExpanded,
                onExpandClick = { kategorienExpanded = !kategorienExpanded }
            ) {
                if (kategorienExpanded) {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        categories.forEach { category ->
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        expandedCategory = if (expandedCategory == category) null else category
                                    },
                                color = Color.Black.copy(alpha = 0.5f)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(8.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = category,
                                        color = Color.White
                                    )
                                    Checkbox(
                                        checked = selectedCategories.contains(category),
                                        onCheckedChange = { checked ->
                                            selectedCategories = if (checked) {
                                                selectedCategories + category
                                            } else {
                                                selectedCategories - category
                                            }
                                        },
                                        colors = CheckboxDefaults.colors(
                                            checkedColor = MaterialTheme.colorScheme.primary,
                                            uncheckedColor = Color.White
                                        )
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Start Game Button
            Button(
                onClick = { startGame() },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 16.dp),
                enabled = selectedCategories.isNotEmpty() && playerNames.size >= 3
            ) {
                Text("Start Game")
            }
        }
    } else {
        // Game Started UI
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFF8B0000))
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (!gameState.allPlayersRevealed) {
                val currentPlayer = playerNames[gameState.currentPlayerIndex]

                Text(
                    text = currentPlayer,
                    fontSize = 32.sp,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(bottom = 32.dp)
                )

                if (!gameState.roleRevealed) {
                    Button(
                        onClick = { 
                            gameState = gameState.copy(
                                roleRevealed = true,
                                revealedPlayers = gameState.revealedPlayers + currentPlayer
                            )
                        }
                    ) {
                        Text("Show Role")
                    }
                } else {
                    // Show role information
                    Text(
                        text = if (gameState.impostors.contains(currentPlayer)) {
                            "You are an Impostor!"
                        } else {
                            "Word: ${gameState.word}"
                        },
                        fontSize = 24.sp,
                        color = Color.White,
                        modifier = Modifier.padding(bottom = 16.dp)
                    )

                    Button(
                        onClick = { showNextPlayer() }
                    ) {
                        Text(
                            if (gameState.currentPlayerIndex == playerNames.size - 1) {
                                "Start Game"
                            } else {
                                "Next Player"
                            }
                        )
                    }
                }
            } else {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Text(
                        text = "${gameState.selectedStartingPlayer} starts the game!",
                        fontSize = 24.sp,
                        color = Color.White
                    )

                    Spacer(modifier = Modifier.height(32.dp))

                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        if (gameState.roleRevealed) {
                            Text(
                                text = "Impostors: ${gameState.impostors.joinToString(", ")}",
                                fontSize = 20.sp,
                                color = Color.White
                            )
                        }

                        Button(
                            onClick = { 
                                gameState = gameState.copy(roleRevealed = true)
                            },
                            enabled = !gameState.roleRevealed
                        ) {
                            Text("Show Impostors")
                        }

                        Button(
                            onClick = { resetGame() },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.secondary
                            )
                        ) {
                            Text("Reset Game")
                        }
                    }
                }
            }
        }
    }

    if (showPlayerNameDialog) {
        Dialog(onDismissRequest = { showPlayerNameDialog = false }) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = MaterialTheme.shapes.medium
            ) {
                Column(
                    modifier = Modifier.padding(16.dp)
                ) {
                    Text(
                        "Edit Player Names",
                        style = MaterialTheme.typography.headlineSmall,
                        modifier = Modifier.padding(bottom = 16.dp)
                    )
                    LazyColumn {
                        items(playerNames.indices.toList()) { index ->
                            var name by remember { mutableStateOf(playerNames[index]) }
                            OutlinedTextField(
                                value = name,
                                onValueChange = { newName ->
                                    name = newName
                                    playerNames = playerNames.toMutableList().also {
                                        it[index] = newName
                                    }
                                },
                                label = { Text("Player ${index + 1}") },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                            )
                        }
                    }
                    Button(
                        onClick = { showPlayerNameDialog = false },
                        modifier = Modifier
                            .align(Alignment.End)
                            .padding(top = 16.dp)
                    ) {
                        Text("Done")
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsSection(
    title: String,
    expanded: Boolean,
    onExpandClick: () -> Unit,
    content: @Composable () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .clickable(onClick = onExpandClick),
            color = Color.Black
        ) {
            Text(
                text = title,
                color = Color.White,
                fontSize = 24.sp,
                modifier = Modifier.padding(8.dp)
            )
        }
        if (expanded) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp)
            ) {
                content()
            }
        }
    }
} 